// Import video data (same as in app.js) - All 17 videos from folders
const videos = [
    {
        id: 1,
        title: "Il Linguaggio della Strada",
        description: "Introduzione al codice visivo della strada e ai principi fondamentali della segnaletica",
        duration: "12:30",
        thumbnail: "thumbnails/video1.jpg",
        videoUrl: "1/Il_Linguaggio_della_Strada.mp4",
        pdfUrl: "1/Il_Codice_Visivo_della_Strada.pdf"
    },
    {
        id: 2,
        title: "Segnali di Pericolo",
        description: "Impara a riconoscere e interpretare tutti i segnali di pericolo italiani",
        duration: "18:45",
        thumbnail: "thumbnails/video2.jpg",
        videoUrl: "2/Segnali_di_Pericolo_Italiani.mp4",
        pdfUrl: "2/Decodificare_la_Strada_Guida_Visiva_ai_Segnali.pdf"
    },
    {
        id: 3,
        title: "Segnali di Divieto",
        description: "Guida completa ai segnali di divieto e le loro applicazioni pratiche",
        duration: "15:20",
        thumbnail: "thumbnails/video3.jpg",
        videoUrl: "3/Guida_ai_Segnali_di_Divieto.mp4",
        pdfUrl: "3/Italian_Prohibition_Signs_Decoded.pdf"
    },
    {
        id: 4,
        title: "Segnali di Obbligo",
        description: "Tutti i segnali blu di obbligo che devi conoscere per l'esame",
        duration: "14:10",
        thumbnail: "thumbnails/video4.jpg",
        videoUrl: "4/Segnali_di_Obbligo.mp4",
        pdfUrl: "4/I_Segnali_Blu.pdf"
    },
    {
        id: 5,
        title: "Segnali di Precedenza",
        description: "Regole fondamentali sulla precedenza e segnaletica dedicata",
        duration: "20:15",
        thumbnail: "thumbnails/video5.jpg",
        videoUrl: "5/Segnali_di_Precedenza.mp4",
        pdfUrl: "5/Precedenza_Strade_Guida_Visiva_Italiana.pdf"
    },
    {
        id: 6,
        title: "Segnali Orizzontali",
        description: "La segnaletica orizzontale: strisce, zebre e marcature stradali",
        duration: "11:30",
        thumbnail: "thumbnails/video6.jpg",
        videoUrl: "6/Segnali_Orizzontali.mp4",
        pdfUrl: "6/Silencio_stradale_decodificato.pdf"
    },
    {
        id: 7,
        title: "Semafori e Gerarchia dei Segnali",
        description: "Come interpretare i semafori e la gerarchia della segnaletica stradale",
        duration: "13:45",
        thumbnail: "thumbnails/video7.jpg",
        videoUrl: "7/Decifrare_i_Semafori_Italiani.mp4",
        pdfUrl: "7/Gerarchia_Dei_Segnali_Stradali.pdf"
    },
    {
        id: 8,
        title: "Segnaletica Stradale Italiana",
        description: "Panoramica completa della segnaletica stradale in Italia",
        duration: "16:20",
        thumbnail: "thumbnails/video8.jpg",
        videoUrl: "8/Segnaletica_Stradale_Italiana.mp4",
        pdfUrl: "8/Silently_generating_the_title_based_on_the_Italian_core_concept.pdf"
    },
    {
        id: 9,
        title: "Pannelli Integrativi",
        description: "Guida ai pannelli integrativi e al contesto dei segnali stradali",
        duration: "10:15",
        thumbnail: "thumbnails/video9.jpg",
        videoUrl: "9/Guida_ai_pannelli_integrativi.mp4",
        pdfUrl: "9/Road_Sign_Context.pdf"
    },
    {
        id: 10,
        title: "Segnali Complementari e Cantieri",
        description: "Segnali complementari, di cantiere e temporanei sulla strada",
        duration: "12:40",
        thumbnail: "thumbnails/video10.jpg",
        videoUrl: "10/Eroi_Nascosti_della_Strada.mp4",
        pdfUrl: "10/Road_Language_Complementary_And_Construction_Signs.pdf"
    },
    {
        id: 11,
        title: "Manuale del Guidatore Proattivo",
        description: "Guida strategica su velocità, pericolo e consapevolezza alla guida",
        duration: "17:30",
        thumbnail: "thumbnails/video11.jpg",
        videoUrl: "11/Manuale_del_Guidatore_Proattivo.mp4",
        pdfUrl: "11/Guida_Strategica_Velocità_Pericolo_Consapevolezza.pdf"
    },
    {
        id: 12,
        title: "La Scienza della Frenata",
        description: "Spazio di sicurezza, distanza di arresto e tecniche di frenata",
        duration: "14:50",
        thumbnail: "thumbnails/video12.jpg",
        videoUrl: "12/La_Scienza_della_Frenata.mp4",
        pdfUrl: "12/Spazio_di_Sicurezza_e_Distanza_di_Arresto.pdf"
    },
    {
        id: 13,
        title: "Le Regole della Strada",
        description: "Guida pratica alla circolazione e al dominio della strada",
        duration: "19:20",
        thumbnail: "thumbnails/video13.jpg",
        videoUrl: "13/Le_Regole_della_Strada.mp4",
        pdfUrl: "13/Il_Dominio_della_Strada_Guida_Pratica_alla_Circolazione.pdf"
    },
    {
        id: 14,
        title: "Precedenza - Chi Passa Per Primo?",
        description: "Regole di precedenza senza errori: chi passa per primo in ogni situazione",
        duration: "15:45",
        thumbnail: "thumbnails/video14.jpg",
        videoUrl: "14/Chi_Passa_Per_Primo_.mp4",
        pdfUrl: "14/Precedenza_Zero_Errori.pdf"
    },
    {
        id: 15,
        title: "Le Regole del Sorpasso",
        description: "Guida completa alle regole e tecniche del sorpasso sicuro",
        duration: "13:25",
        thumbnail: "thumbnails/video15.jpg",
        videoUrl: "15/Le_Regole_del_Sorpasso.mp4",
        pdfUrl: "15/The_Overtaking_Playbook.pdf"
    },
    {
        id: 16,
        title: "Guidare in Italia",
        description: "Controllo del veicolo e regole fondamentali per guidare in Italia",
        duration: "18:10",
        thumbnail: "thumbnails/video16.jpg",
        videoUrl: "16/Guidare_in_Italia.mp4",
        pdfUrl: "16/Mastering_The_Road_Vehicle_Control_and_Rules.pdf"
    },
    {
        id: 17,
        title: "Guidare in Italia - Le Regole",
        description: "Il viaggio del guidatore consapevole: regole complete di guida",
        duration: "16:55",
        thumbnail: "thumbnails/video17.jpg",
        videoUrl: "17/Guidare_in_Italia__Le_Regole.mp4",
        pdfUrl: "17/Il_Viaggio_del_Guidatore_Consapevole.pdf"
    }
];

// State
let currentVideoIndex = 0;
let autoplayEnabled = false;

// Get URL Parameters
function getVideoIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const videoId = parseInt(params.get('video')) || 1;
    return videoId;
}

// Local Storage Functions
function getWatchedVideos() {
    const watched = localStorage.getItem('watchedVideos');
    return watched ? JSON.parse(watched) : [];
}

function markVideoAsWatched(videoId) {
    const watched = getWatchedVideos();
    if (!watched.includes(videoId)) {
        watched.push(videoId);
        localStorage.setItem('watchedVideos', JSON.stringify(watched));
    }
}

function getAutoplayPreference() {
    return localStorage.getItem('autoplay') === 'true';
}

function setAutoplayPreference(enabled) {
    localStorage.setItem('autoplay', enabled.toString());
}

// Load Video
function loadVideo(videoId) {
    const video = videos.find(v => v.id === videoId);
    if (!video) return;

    currentVideoIndex = videos.findIndex(v => v.id === videoId);

    // Update video source
    const videoPlayer = document.getElementById('videoPlayer');
    const videoSource = document.getElementById('videoSource');

    videoSource.src = video.videoUrl;
    videoPlayer.load();

    // Update UI
    document.getElementById('videoTitle').textContent = video.title;
    document.getElementById('videoDescription').textContent = video.description;
    document.getElementById('currentVideoNum').textContent = video.id;
    document.getElementById('totalVideos').textContent = videos.length;

    // Update progress
    updateProgress();

    // Update navigation buttons
    updateNavigationButtons();

    // Update page title
    document.title = `${video.title} - PATENTE+`;

    // Update PDF download button
    updatePdfButton();
}

// Update PDF Download Button
function updatePdfButton() {
    const currentVideo = videos[currentVideoIndex];
    const pdfBtn = document.getElementById('downloadPdfBtn');

    if (currentVideo && currentVideo.pdfUrl) {
        pdfBtn.disabled = false;
        pdfBtn.onclick = () => downloadPdf(currentVideo.pdfUrl, currentVideo.title);
    } else {
        pdfBtn.disabled = true;
    }
}

// Download PDF
function downloadPdf(pdfUrl, videoTitle) {
    // Create a temporary link element
    const link = document.createElement('a');
    link.href = pdfUrl;
    link.download = `${videoTitle.replace(/[^a-z0-9]/gi, '_')}.pdf`;
    link.target = '_blank';

    // Trigger download
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Update Progress Bar
function updateProgress() {
    const watchedVideos = getWatchedVideos();
    const totalVideos = videos.length;
    const completedCount = watchedVideos.length;
    const progressPercent = Math.round((completedCount / totalVideos) * 100);

    document.getElementById('progressText').textContent = `${completedCount} / ${totalVideos}`;
    document.getElementById('progressFill').style.width = progressPercent + '%';
}

// Update Navigation Buttons
function updateNavigationButtons() {
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const currentVideo = videos[currentVideoIndex];

    // Previous button - always enabled if not first video
    prevBtn.disabled = currentVideoIndex === 0;

    // Next button - disabled if last video OR current video not completed
    const isLastVideo = currentVideoIndex === videos.length - 1;
    const isCurrentVideoCompleted = isVideoCompleted(currentVideo.id);

    nextBtn.disabled = isLastVideo || !isCurrentVideoCompleted;

    // Update button text to show why it's disabled
    if (!isLastVideo && !isCurrentVideoCompleted) {
        nextBtn.title = 'Completa questo video per sbloccare il successivo';
    } else {
        nextBtn.title = '';
    }
}

// Check if a video is completed (watched 100%)
function isVideoCompleted(videoId) {
    const completed = localStorage.getItem(`video_${videoId}_completed`);
    return completed === 'true';
}

// Mark video as completed (100% watched)
function markVideoAsCompleted(videoId) {
    localStorage.setItem(`video_${videoId}_completed`, 'true');
    // Also mark as watched for progress tracking
    markVideoAsWatched(videoId);
}

// Navigate to Previous Video
function navigateToPrevious() {
    if (currentVideoIndex > 0) {
        const prevVideo = videos[currentVideoIndex - 1];
        window.location.href = `player.html?video=${prevVideo.id}`;
    }
}

// Navigate to Next Video
function navigateToNext() {
    if (currentVideoIndex < videos.length - 1) {
        const nextVideo = videos[currentVideoIndex + 1];
        window.location.href = `player.html?video=${nextVideo.id}`;
    }
}

// Toggle Autoplay
function toggleAutoplay() {
    autoplayEnabled = !autoplayEnabled;
    setAutoplayPreference(autoplayEnabled);

    const toggle = document.getElementById('autoplayToggle');
    if (autoplayEnabled) {
        toggle.classList.add('active');
    } else {
        toggle.classList.remove('active');
    }
}

// Handle Video End
function handleVideoEnd() {
    const currentVideo = videos[currentVideoIndex];
    markVideoAsWatched(currentVideo.id);
    updateProgress();

    if (autoplayEnabled && currentVideoIndex < videos.length - 1) {
        setTimeout(() => {
            navigateToNext();
        }, 1500); // Wait 1.5 seconds before auto-advancing
    }
}

// Keyboard Shortcuts
function handleKeyboard(e) {
    const videoPlayer = document.getElementById('videoPlayer');

    switch (e.key) {
        case ' ':
            e.preventDefault();
            if (videoPlayer.paused) {
                videoPlayer.play();
            } else {
                videoPlayer.pause();
            }
            break;
        case 'ArrowLeft':
            videoPlayer.currentTime -= 10;
            break;
        case 'ArrowRight':
            videoPlayer.currentTime += 10;
            break;
        case 'f':
            if (videoPlayer.requestFullscreen) {
                videoPlayer.requestFullscreen();
            }
            break;
        case 'n':
            if (currentVideoIndex < videos.length - 1) {
                navigateToNext();
            }
            break;
        case 'p':
            if (currentVideoIndex > 0) {
                navigateToPrevious();
            }
            break;
        case 'd':
            // Download PDF with 'd' key
            const currentVideo = videos[currentVideoIndex];
            if (currentVideo && currentVideo.pdfUrl) {
                downloadPdf(currentVideo.pdfUrl, currentVideo.title);
            }
            break;
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    const videoId = getVideoIdFromUrl();

    // Security Check: Prevent access to locked videos via URL
    if (videoId > 1) {
        const prevVideoId = videoId - 1;
        const isPrevCompleted = localStorage.getItem(`video_${prevVideoId}_completed`) === 'true';

        if (!isPrevCompleted) {
            alert("⚠️ Devi completare i video precedenti in sequenza!");
            window.location.href = 'index.html';
            return;
        }
    }

    loadVideo(videoId);

    // Setup autoplay preference
    autoplayEnabled = getAutoplayPreference();
    const toggle = document.getElementById('autoplayToggle');
    if (autoplayEnabled) {
        toggle.classList.add('active');
    }

    // Event Listeners
    const videoPlayer = document.getElementById('videoPlayer');

    videoPlayer.addEventListener('ended', handleVideoEnd);

    // Track video progress and mark as completed at 100%
    videoPlayer.addEventListener('timeupdate', () => {
        const progress = (videoPlayer.currentTime / videoPlayer.duration) * 100;
        const currentVideo = videos[currentVideoIndex];

        // Mark as watched at 90% for progress tracking
        if (progress >= 90) {
            markVideoAsWatched(currentVideo.id);
            updateProgress();
        }

        // Mark as completed at 100% (or very close to end)
        if (progress >= 99.5 || videoPlayer.currentTime >= videoPlayer.duration - 0.5) {
            if (!isVideoCompleted(currentVideo.id)) {
                markVideoAsCompleted(currentVideo.id);
                updateNavigationButtons(); // Re-enable next button
            }
        }
    });

    document.getElementById('prevBtn').addEventListener('click', navigateToPrevious);
    document.getElementById('nextBtn').addEventListener('click', navigateToNext);
    document.getElementById('autoplayToggle').addEventListener('click', toggleAutoplay);
    document.addEventListener('keydown', handleKeyboard);
});
